document.getElementById("openSettings").addEventListener("click", () => {
  browser.runtime.openOptionsPage();
});
